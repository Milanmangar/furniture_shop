==================
Furniture Factory
==================


Quick start
-----------

1. pip install djangorestframework==3.12.2

2. Add "furniture_factory" to your INSTALLED_APPS setting like this::

    INSTALLED_APPS = [
        ...
        'table',
    ]

3. Include the furniture_factory URLconf in your project urls.py like this::

    path('table/', include('table.urls')),

4. Run ``python manage.py migrate`` to create the polls models.

5. Start the development server and visit http://127.0.0.1:8000/admin/
   to create a poll (you'll need the Admin app enabled).

6. Visit http://127.0.0.1:8000/table/ to participate in the poll.